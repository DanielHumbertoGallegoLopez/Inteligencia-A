
package bicicleta;

public class Bicicleta {

    private boolean marco;
    private boolean timon;
    private boolean llantas;
    private boolean pedales;
    
    public Bicicleta(){
        marco = false;
        timon = false;
        llantas = false;
        pedales = false;
    }
    public void setMarco(boolean set){
        marco = set;
    }
    
    public boolean isMarco(){
        return marco;
    }
    
    public void setPedales(boolean set){
        pedales = set;
    }
    
    public boolean isPedales(){
        return pedales;
    }
    
    public void setTimon(boolean set){
        timon = set;
    }
    
    public boolean isTimon(){
        return timon;
    }
    
    public void setLlantas(boolean set){
        llantas = set;
    }
    
    public boolean isLlantas(){
        return llantas;
    }
}