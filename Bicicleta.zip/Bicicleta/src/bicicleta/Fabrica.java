package bicicleta;

import jade.core.*;
import jade.core.behaviours.*;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.domain.FIPAException;
import jade.lang.acl.ACLMessage;

public class Fabrica extends Agent
{
    class ReceptorComportaminento extends CyclicBehaviour
    {

            public void action()
            {
                System.out.println("Preparandose para recibir un mensaje del Cliente");
                
                ACLMessage mensaje = receive();
                
                if (mensaje != null)
                {
                    switch (mensaje.getContent()) {
                        case "1":
                            //arma la bicicleta
                            System.out.println("Opcion 1 escogida");
                            System.out.println("Ensamblar la bicicleta");
                            FmsBicicleta armarBicicleta = new FmsBicicleta();
                            armarBicicleta.setup();
                            System.out.println(armarBicicleta.getResultado());
                            if (armarBicicleta.getResultado()==true){
                                System.out.println("Bicicleta creada");
                            }
                            break;
                        case "2":
                            // finaliza
                            System.out.println("Adios");
                            break;
                        default:
                            System.out.println(getLocalName() + ": acabo de recibir el siguiente mensaje: ");
                            System.out.println(mensaje.getContent());
                            ACLMessage respuesta = mensaje.createReply();
                            respuesta.setPerformative(ACLMessage.INFORM);
                            respuesta.setContent("Hola en que lo puedo ayudar \n1. Ensamblar Bicicleta. \n2. Salir");
                            send(respuesta);
                            break;
                    }
                }
                    else{
                        System.out.println("Receptor: Esperando a recibir mensaje...");
                        block();
                    }
            }
    }
    @Override
    protected void setup()
    {   
        System.out.println("El agente es " + this.getLocalName()+ ", Yo doy el servicio Tipo de Servicio 1");
        registrerService();
        addBehaviour(new ReceptorComportaminento());
        
    }
    
    private void registrerService()
    {
        DFAgentDescription dfd= new DFAgentDescription();
        dfd.setName(this.getAID());

        ServiceDescription sd = new ServiceDescription();
        sd.setType("Tipo de Servicio 1");
        sd.setName("Nombre de Servicio 1");
        
              
        dfd.addServices(sd);
        
        try {
            DFService.register(this,dfd);
        }
        catch (FIPAException ex)
        {
            System.err.println("El agente:" + getLocalName() +  "No ha podido registrar el servicio: " + ex.getMessage());
            doDelete();
        }   

    }
}