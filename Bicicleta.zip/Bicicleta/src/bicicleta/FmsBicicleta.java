
package bicicleta;

import jade.core.Agent;
import jade.core.behaviours.*;
import java.lang.*;

public class FmsBicicleta extends Agent {

    private static final String marco = "marco";
    private static final String llantas = "llantas";
    private static final String pedales = "pedales";
    private static final String timon = "timon";
    private static final String terminado = "bicicleta ensamblada";
    private String entrada;
    private boolean resultado;
    
    public void setup(){
        entrada="231231231";
        MiFSMBehaviour b = new MiFSMBehaviour(this, entrada) {
            public int onEnd() {
                    System.out.println("FSM behaviour completed.");
                    myAgent.doDelete();
                    return super.onEnd();
            }
        };
        b.onStart();
        addBehaviour(b);
    }
    
    public boolean getResultado(){
        return resultado;
    }

    private class MiFSMBehaviour extends FSMBehaviour {

        private int transicion = 0;
        private String entrada = "";
        private Bicicleta nuevabicicleta = new Bicicleta();

        public MiFSMBehaviour(Agent _agente, String ent) {
        //public MiFSMBehaviour() {
            super(_agente);
            entrada = ent;
            
        }
        

        public void onStart() {
            System.out.println("Registrando estados");
            registerFirstState(new OneBehaviour(), marco);
            registerState(new TwoBehaviour(), llantas);
            registerState(new ThreeBehaviour(), pedales);
            registerState(new FourBehaviour(), timon);
            registerLastState(new FinalBehaviour(), terminado);
            registerTransition(marco, llantas, 1);
            registerTransition(marco, pedales,  0);
            registerTransition(llantas, pedales, 1);
            registerTransition(pedales, llantas, 0);
            registerTransition(llantas, llantas, 1);
            registerTransition(llantas, timon, 0);
            registerTransition(pedales, timon, 1);
            registerTransition(timon, terminado, 1);
            registerDefaultTransition(timon, terminado);
        }

        private class OneBehaviour extends OneShotBehaviour {

            public void action() {
                System.out.println("Marco");
                nuevabicicleta.setMarco(true);
                System.out.println("armando el marco");
            }

            public int onEnd() {
                
                if (!nuevabicicleta.isMarco()) {
                    return 1;
                }else{
                    return 0;
                    
                }
               
            }
        }

        private class TwoBehaviour extends OneShotBehaviour {

            public void action() {
                System.out.println("Llantas");
                nuevabicicleta.setLlantas(true);
                System.out.println("Armando las llantas");
            }

            public int onEnd() {
                if (!nuevabicicleta.isLlantas()) {
                    return 1;
                }else{
                    return 0;
                }
            }
        }

        private class ThreeBehaviour extends OneShotBehaviour {

            public void action() {
                System.out.println("Pedales");
                nuevabicicleta.setPedales(true);
                System.out.println("Armando los pedales");
            }

            public int onEnd() {
                if (!nuevabicicleta.isPedales()) {
                    return 1;
                }else{
                    return 0;
                }
            }
        }

        private class FourBehaviour extends OneShotBehaviour {

            public void action() {
                System.out.println("Timon");
                nuevabicicleta.setTimon(true);
                System.out.println("Armando el Timon");
            }

            public int onEnd() {
                if (!nuevabicicleta.isTimon()) {
                    return 1;
                }else{
                    return 0;
                }
            }
        }

        private class FinalBehaviour extends OneShotBehaviour {

            public void action() {
                System.out.println("bicicleta ensamblada");
                //resultado = true;
            }
            
            public int onEnd() {
                if (!nuevabicicleta.isTimon() && 
                    !nuevabicicleta.isLlantas() &&
                    !nuevabicicleta.isMarco() &&
                    !nuevabicicleta.isPedales()){
                    resultado = true;
                    return 1;
                }else{
                    return 0;
                }
            }
                       
        }
    }
}
