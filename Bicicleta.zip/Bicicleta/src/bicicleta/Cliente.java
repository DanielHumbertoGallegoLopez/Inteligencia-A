
package bicicleta;

import jade.core.*;
import jade.core.behaviours.*;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.domain.FIPAException;
import jade.lang.acl.ACLMessage;
import jade.util.leap.Iterator;
 
public class Cliente extends Agent{
    
    class ClienteComportaminento extends SimpleBehaviour {  
        public void action()
        {
            System.out.println(getLocalName() +": Preparandose para enviar un mensaje a Fabrica ");
            AID id = new AID();
            id.setLocalName("Fabrica");

            ACLMessage mensaje = new ACLMessage(ACLMessage.REQUEST);
 
            mensaje.setSender(getAID());
            mensaje.addReceiver(id);
            mensaje.setContent("Hola Fabrica");
 
            send(mensaje);
            //bicicleta creada
            ACLMessage msg = blockingReceive();
            System.out.println("mensaje recibido");
            System.out.println(msg.getContent());
            
            ACLMessage mensaje2 = new ACLMessage(ACLMessage.REQUEST);
            
            mensaje2.setSender(getAID());
            mensaje2.addReceiver(id);
            mensaje2.setContent("1");
            
            send(mensaje2);
            
            ACLMessage msg2 = blockingReceive();
            System.out.println("mensaje de confirmacion");
            System.out.println(msg2.getContent());
        }
        @Override
        public boolean done()
        {
            return true;
        }
            
          }
    @Override
    protected void setup()
    {  
       
        registrerService();
        addBehaviour(new ClienteComportaminento());
        
    }
    
    private void registrerService()
    {
        ServiceDescription svc = new ServiceDescription();
        svc.setType("Tipo de Servicio 1");
        svc.setName("Nombre de Servicio 1");
 
    // Plantilla de descripción que busca el agente
        DFAgentDescription descripcion = new DFAgentDescription();
 
    // Servicio que busca el agente
        descripcion.addServices(svc);
        try
        {
            DFAgentDescription[] resultados = DFService.search(this,descripcion);
 
            if (resultados.length == 0)
                System.out.println("Ningun agente ofrece el servicio deseado");
 
            for (int i = 0; i < resultados.length; ++i)
            {
                System.out.println("El agente "+resultados[i].getName()+" ofrece los siguientes servicios:");
                Iterator servicios = resultados[i].getAllServices();
                int j = 1;
                while(servicios.hasNext())
                {
                    svc = (ServiceDescription)servicios.next();
                    System.out.println(j+"- "+svc.getName());
                    System.out.println();
                    j++;
                }
            }
        }
        catch (FIPAException ex)
        {
            System.err.println("El agente:" + getLocalName() +  "No ha podido registrar el servicio: " + ex.getMessage());
            doDelete();
        }   
        
    }
}   